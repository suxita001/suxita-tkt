# -*- coding: utf-8 -*-
"""
ღიპიანი თამადა — ფრენა თბილისის ცაში
ორიგინალური თამაში: ღიპიანი თამადა ყანწით დაფრინავს თბილისის უბნებში,
აგროვებს ხინკალს და გვერდს უვლის მახინჯ მაღალსართულიანებს.

მართვა: SPACE / ↑ / მაუსის კლიკი — ფრენა, P — პაუზა, M — ხმა, F11 — სრული ეკრანი, ESC — მენიუ/გასვლა
"""
import os
import sys
import math
import json
import random
import asyncio
from array import array

import pygame

# ----------------------------------------------------------------------------
# კონსტანტები
# ----------------------------------------------------------------------------
W, H = 480, 800
GROUND_H = 96
GROUND_Y = H - GROUND_H
FPS = 60
TITLE = "ღიპიანი თამადა"

GRAVITY = 1750.0
FLAP_V = -560.0
MAX_FALL = 900.0
PLAYER_X = 130

BODY_W = 92          # შენობის სხეულის სიგანე (ჰიტბოქსი)
DECOR_M = 18         # გვერდითი ადგილი მიშენებებისთვის
ROOF_M = 46          # სახურავის დეკორი
UNDER_M = 26         # ჩამოკიდებული შენობის ქვედა დეკორი
FLOOR = 36

LW = 960             # ფონის ფენის სიგანე (tileable)
LAYER_H = 440

DEATH_MSGS = [
    "ვაიმე! უკანონო მიშენებას შეასკდი!",
    "ეს კორპუსი ნებართვის გარეშე აშენდა!",
    "ყანწი დაიღვარა...",
    "ხინკალი ცოტა ბევრი ხომ არ იყო?",
    "თამადამ ვერ გაიტანა!",
    "ალავერდი შემდეგ ცდას!",
    "ვინ ააშენა ეს მახინჯი?!",
]
GROUND_MSGS = ["ორმოში ჩავარდი!", "ასფალტს აკოცე!", "მარშრუტკას ელოდები?"]
TOASTS = ["გაუმარჯოს!", "ალავერდი!", "ბოლომდე!", "გაგიმარჯოს, თბილისო!", "სადღეგრძელო!"]
SIGNS = ["ხინკალი", "ლობიანი", "ბინები", "იყიდება", "ქირავდება", "SALE", "ხაჭაპური"]

KERZ_COLS = [(120, 160, 190), (205, 205, 198), (150, 110, 80), (110, 150, 110), (190, 120, 90),
             (232, 226, 200), (90, 110, 140), (170, 170, 120), (200, 90, 80)]
LAUNDRY_COLS = [(230, 60, 60), (60, 120, 220), (250, 250, 250), (250, 200, 40), (120, 200, 120),
                (240, 140, 190)]


def clamp(v, a, b):
    return a if v < a else b if v > b else v


def lerp(a, b, t):
    return a + (b - a) * t


def lerp_col(c1, c2, t):
    return tuple(int(lerp(c1[i], c2[i], t)) for i in range(3))


def shade(c, f):
    return tuple(clamp(int(x * f), 0, 255) for x in c[:3])


def circle_rect(cx, cy, r, rect):
    nx = clamp(cx, rect.left, rect.right)
    ny = clamp(cy, rect.top, rect.bottom)
    return (cx - nx) ** 2 + (cy - ny) ** 2 < r * r


def bezier(p0, p1, p2, t):
    a = (1 - t) ** 2
    b = 2 * (1 - t) * t
    c = t * t
    return (a * p0[0] + b * p1[0] + c * p2[0], a * p0[1] + b * p1[1] + c * p2[1])


# ----------------------------------------------------------------------------
# შრიფტები და ტექსტი
# ----------------------------------------------------------------------------
def find_font():
    windir = os.environ.get("WINDIR", r"C:\Windows")
    for name in ("segoeuib.ttf", "sylfaen.ttf", "segoeui.ttf"):
        p = os.path.join(windir, "Fonts", name)
        if os.path.exists(p):
            return p
    # ვებ-ვერსიისთვის: თამაშთან ერთად მოყოლილი შრიფტი
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, "DejaVuSans-Bold.ttf")
    if os.path.exists(p):
        return p
    return None


FONT_PATH = None
_font_cache = {}
_text_cache = {}


def get_font(size):
    f = _font_cache.get(size)
    if f is None:
        if FONT_PATH:
            f = pygame.font.Font(FONT_PATH, size)
        else:
            f = pygame.font.SysFont("sylfaen,segoeui,arial", size, bold=True)
        _font_cache[size] = f
    return f


def text_surf(text, size, color=(255, 255, 255), outline=(45, 25, 15), ow=3):
    key = (text, size, color, outline, ow)
    s = _text_cache.get(key)
    if s is not None:
        return s
    if len(_text_cache) > 500:
        _text_cache.clear()
    f = get_font(size)
    base = f.render(text, True, color)
    if outline is None or ow <= 0:
        s = base
    else:
        o = f.render(text, True, outline)
        w, h = base.get_size()
        s = pygame.Surface((w + ow * 2, h + ow * 2), pygame.SRCALPHA)
        for dx in range(-ow, ow + 1):
            for dy in range(-ow, ow + 1):
                if dx * dx + dy * dy <= ow * ow + 1:
                    s.blit(o, (ow + dx, ow + dy))
        s.blit(base, (ow, ow))
    _text_cache[key] = s
    return s


def draw_text(surf, text, size, pos, color=(255, 255, 255), outline=(45, 25, 15), ow=3,
              anchor="center", alpha=255):
    s = text_surf(text, size, color, outline, ow)
    if alpha < 255:
        s = s.copy()
        s.set_alpha(max(0, int(alpha)))
    r = s.get_rect(**{anchor: (int(pos[0]), int(pos[1]))})
    surf.blit(s, r)
    return r


# ----------------------------------------------------------------------------
# გმირი: ღიპიანი თამადა ყანწით
# ----------------------------------------------------------------------------
SKIN = (238, 192, 150)
SKIN_D = (200, 145, 110)
SHIRT = (246, 246, 240)
OUTL = (60, 38, 28)
HAIR = (30, 24, 22)


def make_player_frame(arm_up, leg):
    S = pygame.Surface((110, 110), pygame.SRCALPHA)
    cx, cy = 52, 58

    # უკანა ხელი
    pygame.draw.line(S, OUTL, (cx - 6, cy - 12), (cx - 22, cy + 2 - (6 if arm_up else 0)), 11)
    pygame.draw.line(S, (220, 220, 212), (cx - 6, cy - 12), (cx - 22, cy + 2 - (6 if arm_up else 0)), 8)
    pygame.draw.circle(S, SKIN_D, (cx - 23, cy + 3 - (6 if arm_up else 0)), 5)

    # ფეხები (შარვალი + ფეხსაცმელი)
    pants = (48, 48, 64)
    for i, dx in enumerate((-7, 5)):
        sx, sy = cx - 2 + dx, cy + 14
        ex, ey = cx - 20 + dx + (leg if i else -leg), cy + 36
        pygame.draw.line(S, OUTL, (sx, sy), (ex, ey), 13)
        pygame.draw.line(S, pants, (sx, sy), (ex, ey), 10)
        pygame.draw.ellipse(S, (20, 18, 18), (ex - 5, ey - 4, 15, 9))

    # ღიპი
    belly = pygame.Rect(0, 0, 58, 52)
    belly.center = (cx + 3, cy + 4)
    pygame.draw.ellipse(S, OUTL, belly.inflate(5, 5))
    pygame.draw.ellipse(S, SHIRT, belly)
    pygame.draw.ellipse(S, (222, 222, 214), (belly.x + 4, belly.y + 26, belly.w - 14, belly.h - 28))
    # ღილებს შორის გამოჩენილი ღიპი
    pygame.draw.ellipse(S, SKIN, (belly.right - 17, cy + 2, 12, 16))
    pygame.draw.circle(S, SKIN_D, (belly.right - 11, cy + 11), 2)
    for k in range(4):
        a = -1.2 + k * 0.55
        bx = belly.centerx + int(math.cos(a) * 26)
        by = belly.centery + int(math.sin(a) * 23)
        if k == 2:
            continue
        pygame.draw.circle(S, (150, 150, 150), (bx, by), 2)
    # ქამარი
    pygame.draw.arc(S, (90, 55, 30), belly.inflate(-6, 0).move(0, 3), math.pi * 1.15, math.pi * 1.85, 4)

    # თავი
    hx, hy = cx + 4, cy - 30
    pygame.draw.circle(S, OUTL, (hx, hy), 17)
    pygame.draw.circle(S, SKIN, (hx, hy), 15)
    pygame.draw.ellipse(S, HAIR, (hx - 16, hy - 17, 26, 13))
    pygame.draw.rect(S, HAIR, (hx - 15, hy - 9, 7, 11), border_radius=3)
    pygame.draw.circle(S, SKIN_D, (hx - 4, hy + 1), 4)
    pygame.draw.circle(S, (245, 160, 150), (hx + 7, hy + 4), 4)       # ლოყა
    pygame.draw.circle(S, (20, 20, 20), (hx + 8, hy - 3), 2)          # თვალი
    pygame.draw.line(S, HAIR, (hx + 3, hy - 9), (hx + 12, hy - 8), 3)  # წარბი
    pygame.draw.circle(S, (226, 128, 112), (hx + 15, hy + 1), 5)      # ცხვირი
    pygame.draw.ellipse(S, HAIR, (hx + 4, hy + 4, 17, 7))             # ულვაში
    pygame.draw.line(S, HAIR, (hx + 6, hy + 8), (hx + 3, hy + 13), 3)
    pygame.draw.line(S, HAIR, (hx + 19, hy + 8), (hx + 21, hy + 13), 3)

    # წინა ხელი და ყანწი
    shoulder = (cx + 2, cy - 14)
    hand = (cx + 28, cy - 30) if arm_up else (cx + 32, cy - 8)
    pygame.draw.line(S, OUTL, shoulder, hand, 12)
    pygame.draw.line(S, SHIRT, shoulder, hand, 9)
    mouth = (hand[0] + 2, hand[1] - 10)
    ctrl = (hand[0] + 24, hand[1] - 4)
    tip = (hand[0] + 12, hand[1] + 18)
    n = 18
    for i in range(n, -1, -1):
        t = i / n
        p = bezier(mouth, ctrl, tip, t)
        r = lerp(7.5, 1.6, t)
        col = lerp_col((70, 40, 24), (196, 166, 120), t)
        pygame.draw.circle(S, OUTL, (int(p[0]), int(p[1])), int(r + 1.5))
        pygame.draw.circle(S, col, (int(p[0]), int(p[1])), int(r))
    pygame.draw.ellipse(S, (205, 205, 215), (mouth[0] - 9, mouth[1] - 4, 18, 8))
    pygame.draw.ellipse(S, (130, 10, 35), (mouth[0] - 6, mouth[1] - 2, 12, 4))
    pygame.draw.circle(S, OUTL, hand, 7)
    pygame.draw.circle(S, SKIN, hand, 6)
    return S


# ----------------------------------------------------------------------------
# ხინკალი
# ----------------------------------------------------------------------------
def make_khinkali(sz=40):
    """ხინკალი: ფართო, მრგვალი ძირი, ბევრი ნაოჭი, რომლებიც კუდთან იყრის თავს."""
    S = pygame.Surface((sz, sz), pygame.SRCALPHA)
    k = sz / 40.0
    base = (240, 224, 182)
    light = (253, 245, 222)
    dark = (206, 182, 134)
    edge = (150, 118, 78)
    knob = (20 * k, 8 * k)
    pts = []
    for i in range(41):
        a = math.pi * i / 40
        pts.append((20 * k - math.cos(a) * 18 * k, 31 * k + math.sin(a) * 6 * k))
    shape = [(2 * k, 31 * k)]
    for i in range(21):
        t = i / 20
        x = lerp(2 * k, 38 * k, t)
        bulge = math.sin(math.pi * t)
        y = 31 * k - bulge * 15 * k - (1 - abs(t - 0.5) * 2) ** 3 * 8 * k
        shape.append((x, y))
    shape += list(reversed(pts))
    for ox, oy in ((-1, 0), (1, 0), (0, -1), (0, 1), (1, 1), (-1, 1)):
        pygame.draw.polygon(S, edge, [(x + ox, y + oy) for x, y in shape])
    pygame.draw.polygon(S, base, shape)
    # ქვედა ჩრდილი
    pygame.draw.ellipse(S, dark, (4 * k, 29 * k, 32 * k, 7 * k))
    # ნაოჭები
    n = 13
    for i in range(n):
        t = i / (n - 1)
        ex = lerp(3.5 * k, 36.5 * k, t)
        ey = 31 * k - math.sin(math.pi * t) * 7 * k
        ctrl = (lerp(knob[0], ex, 0.75) + 3 * k, lerp(knob[1], ey, 0.35))
        line = [bezier(knob, ctrl, (ex, ey), j / 8) for j in range(9)]
        pygame.draw.lines(S, dark, False, line, max(1, int(1.6 * k)))
        line2 = [(x - 1.3 * k, y) for x, y in line[2:]]
        pygame.draw.lines(S, light, False, line2, 1)
    # კუდი (დაგრეხილი)
    kp = [(16 * k, 12 * k), (24 * k, 12 * k), (22.5 * k, 1.5 * k), (17.5 * k, 1.5 * k)]
    for ox, oy in ((-1, 0), (1, 0), (0, -1)):
        pygame.draw.polygon(S, edge, [(x + ox, y + oy) for x, y in kp])
    pygame.draw.polygon(S, base, kp)
    for j in range(3):
        y = (4 + j * 3) * k
        pygame.draw.line(S, dark, (17.5 * k, y + 2 * k), (22.5 * k, y), 1)
    pygame.draw.ellipse(S, (255, 252, 240), (9 * k, 20 * k, 6 * k, 3 * k))
    return S


# ----------------------------------------------------------------------------
# მახინჯი შენობები
# ----------------------------------------------------------------------------
def floor_rows(body, hanging):
    rows = []
    if not hanging:
        fy = body.top + 10
        while fy < body.bottom:
            rows.append(fy)
            fy += FLOOR
    else:
        fy = body.bottom - 10 - FLOOR
        while fy > body.top - FLOOR:
            rows.append(fy)
            fy -= FLOOR
    return rows


def win_xs(body):
    return (body.left + 11, body.left + 37, body.left + 63)


def draw_window(S, r, rng, frame=(225, 225, 220), lit_p=0.12):
    pygame.draw.rect(S, frame, r)
    inner = r.inflate(-4, -4)
    p = rng.random()
    if p < lit_p:
        col = (250, 220, 120)
    elif p < lit_p + 0.15:
        col = rng.choice([(200, 90, 80), (120, 150, 90), (220, 200, 150), (180, 120, 170)])
    else:
        col = (60, 80, 105)
    pygame.draw.rect(S, col, inner)
    pygame.draw.line(S, frame, (inner.centerx, inner.top), (inner.centerx, inner.bottom - 1), 1)
    if col == (60, 80, 105):
        pygame.draw.line(S, (110, 135, 160), (inner.left + 1, inner.bottom - 2), (inner.left + 4, inner.top + 1), 1)


def draw_ac(S, x, y):
    r = pygame.Rect(x, y, 14, 10)
    pygame.draw.rect(S, (236, 236, 230), r)
    pygame.draw.rect(S, (140, 140, 140), r, 1)
    pygame.draw.circle(S, (140, 140, 140), (x + 9, y + 5), 3, 1)
    pygame.draw.line(S, (90, 140, 210), (x + 3, y + 10), (x + 3, y + 15), 1)


def draw_laundry(S, x1, x2, y, rng):
    pygame.draw.line(S, (60, 60, 60), (x1, y), (x2, y), 1)
    x = x1 + 3
    while x < x2 - 6:
        w = rng.randint(4, 8)
        h = rng.randint(6, 11)
        pygame.draw.rect(S, rng.choice(LAUNDRY_COLS), (x, y + 1, w, h))
        x += w + rng.randint(2, 5)


def draw_kerz(S, rect, body, rng):
    """უკანონო მიშენება ('კერძო მიშენება') — ფასადიდან გამოშვერილი ყუთი."""
    col = rng.choice(KERZ_COLS)
    dark = shade(col, 0.74)
    pygame.draw.rect(S, col, rect)
    mat = rng.randint(0, 2)
    if mat == 0:
        for xx in range(rect.left + 3, rect.right, 4):
            pygame.draw.line(S, dark, (xx, rect.top), (xx, rect.bottom - 1))
    elif mat == 1:
        for i, yy in enumerate(range(rect.top + 4, rect.bottom, 5)):
            pygame.draw.line(S, dark, (rect.left, yy), (rect.right - 1, yy))
            for xx in range(rect.left + (4 if i % 2 else 0), rect.right, 9):
                pygame.draw.line(S, dark, (xx, yy - 5), (xx, yy))
    else:
        for yy in range(rect.top + 3, rect.bottom, 4):
            pygame.draw.line(S, dark, (rect.left, yy), (rect.right - 1, yy))
    wr = pygame.Rect(0, 0, max(8, rect.w // 2 - 2), max(8, rect.h // 2 - 2))
    wr.center = rect.center
    pygame.draw.rect(S, (230, 230, 225), wr)
    pygame.draw.rect(S, (70, 95, 120) if rng.random() < 0.8 else (250, 220, 120), wr.inflate(-3, -3))
    pygame.draw.rect(S, shade(col, 0.5), rect, 2)
    pygame.draw.line(S, (115, 115, 120), (rect.left - 2, rect.top), (rect.right + 1, rect.top - 2), 3)
    # საყრდენი მილი
    if rect.centerx < body.centerx:
        pygame.draw.line(S, (70, 70, 75), (rect.left + 3, rect.bottom), (body.left + 5, rect.bottom + 12), 2)
    else:
        pygame.draw.line(S, (70, 70, 75), (rect.right - 3, rect.bottom), (body.right - 5, rect.bottom + 12), 2)


def add_kerzebi(S, body, rows, rng, count):
    rows = rows[:12]
    for _ in range(count):
        if not rows:
            return
        fy = rng.choice(rows)
        w = rng.randint(26, 40)
        h = FLOOR * rng.randint(1, 2) - 5
        if rng.random() < 0.5:
            x = body.left - rng.randint(6, DECOR_M - 3)
        else:
            x = body.right - w + rng.randint(6, DECOR_M - 3)
        draw_kerz(S, pygame.Rect(x, fy + 3, w, h), body, rng)


def facade_panel(S, body, rng, hanging):
    wall = rng.choice([(168, 166, 158), (182, 177, 166), (152, 156, 160), (175, 165, 150)])
    pygame.draw.rect(S, wall, body)
    seam = shade(wall, 0.86)
    rows = floor_rows(body, hanging)
    for fy in rows:
        pygame.draw.line(S, seam, (body.left, fy), (body.right - 1, fy))
    for sx in (body.left + 31, body.left + 61):
        pygame.draw.line(S, seam, (sx, body.top), (sx, body.bottom))
    for fy in rows:
        for wx in win_xs(body):
            draw_window(S, pygame.Rect(wx, fy + 8, 18, 20), rng)
        if rng.random() < 0.38:
            wx = rng.choice(win_xs(body))
            br = pygame.Rect(wx - 6, fy + 4, 30, FLOOR - 6)
            col = rng.choice(KERZ_COLS)
            pygame.draw.rect(S, col, br)
            pygame.draw.rect(S, (160, 195, 215), (br.x + 2, br.y + 2, br.w - 4, br.h // 2))
            for px in range(br.x + 8, br.right - 2, 7):
                pygame.draw.line(S, (235, 235, 235), (px, br.y + 2), (px, br.y + br.h // 2 + 1))
            pygame.draw.rect(S, shade(col, 0.55), br, 1)
            if rng.random() < 0.3:
                draw_laundry(S, br.left + 2, br.right - 2, br.top + 3, rng)
        if rng.random() < 0.3:
            draw_ac(S, rng.choice(win_xs(body)) + rng.choice((-15, 19)), fy + 18)
    add_kerzebi(S, body, rows, rng, rng.randint(1, 3))
    return wall


def facade_khrush(S, body, rng, hanging):
    wall = rng.choice([(200, 165, 130), (212, 182, 150), (190, 150, 140), (196, 120, 100)])
    pygame.draw.rect(S, wall, body)
    sp = shade(wall, 0.88)
    for _ in range(260):
        x = rng.randint(body.left, body.right - 3)
        y = rng.randint(max(body.top, 0), body.bottom - 3)
        pygame.draw.rect(S, sp, (x, y, 2, 2))
    rows = floor_rows(body, hanging)
    for fy in rows:
        for wx in win_xs(body):
            draw_window(S, pygame.Rect(wx, fy + 8, 18, 20), rng, frame=(150, 100, 60))
        if rng.random() < 0.5:
            wx = rng.choice(win_xs(body))
            y0 = fy + FLOOR - 8
            pygame.draw.rect(S, (120, 120, 118), (wx - 7, y0, 32, 4))
            for px in range(wx - 6, wx + 25, 4):
                pygame.draw.line(S, (55, 55, 60), (px, y0 - 9), (px, y0))
            pygame.draw.line(S, (55, 55, 60), (wx - 7, y0 - 9), (wx + 24, y0 - 9), 2)
            if rng.random() < 0.5:
                pygame.draw.circle(S, (70, 150, 70), (wx + rng.randint(-3, 20), y0 - 11), 4)
            if rng.random() < 0.4:
                draw_laundry(S, wx - 6, wx + 24, fy + 4, rng)
        if rng.random() < 0.25:
            draw_ac(S, rng.choice(win_xs(body)) + rng.choice((-15, 19)), fy + 16)
    add_kerzebi(S, body, rows, rng, rng.randint(2, 5))
    return wall


def facade_tower(S, body, rng, hanging):
    glass = rng.choice([(70, 140, 165), (55, 105, 140), (90, 160, 150), (120, 110, 160), (60, 95, 85)])
    pygame.draw.rect(S, glass, body)
    light = shade(glass, 1.4)
    dark = shade(glass, 0.7)
    rows = floor_rows(body, hanging)
    cols = list(range(body.left + 11, body.right, 17))
    for fy in rows:
        for xx in cols:
            if rng.random() < 0.1:
                pygame.draw.rect(S, (250, 222, 130), (xx + 2, fy + 4, 13, FLOOR - 8))
    for fy in rows:
        pygame.draw.line(S, light, (body.left, fy), (body.right - 1, fy), 2)
    for xx in cols:
        pygame.draw.line(S, dark, (xx, body.top), (xx, body.bottom))
    ov = pygame.Surface(body.size, pygame.SRCALPHA)
    for k in range(3):
        x0 = rng.randint(-40, BODY_W)
        pygame.draw.polygon(ov, (255, 255, 255, 38), [(x0, 0), (x0 + 22, 0), (x0 + 22 - 400, 800), (x0 - 400, 800)])
    S.blit(ov, body.topleft)
    band = rng.choice([(210, 160, 40), (200, 70, 60), (230, 200, 120), (160, 60, 140)])
    step = rng.randint(3, 5)
    for i, fy in enumerate(rows):
        if i % step == 1:
            pygame.draw.rect(S, band, (body.left, fy - 3, BODY_W, 6))
    if rng.random() < 0.45:
        side = pygame.Rect(body.left if rng.random() < 0.5 else body.right - 26, body.top, 26, body.h)
        stone = rng.choice([(215, 200, 170), (180, 90, 70), (230, 225, 215)])
        pygame.draw.rect(S, stone, side)
        for fy in rows:
            pygame.draw.line(S, shade(stone, 0.8), (side.left, fy), (side.right - 1, fy))
            pygame.draw.rect(S, (60, 80, 105), (side.left + 7, fy + 9, 12, 16))
    return glass


def facade_karkasi(S, body, rng, hanging):
    concrete = (150, 146, 138)
    pygame.draw.rect(S, (42, 40, 38), body)
    rows = floor_rows(body, hanging)
    bays = [(body.left + 7, body.centerx - 3), (body.centerx + 4, body.right - 7)]
    for fy in rows:
        for (a, b) in bays:
            p = rng.random()
            r = pygame.Rect(a, fy + 7, b - a, FLOOR - 7)
            if p < 0.3:
                hh = r.h if rng.random() < 0.6 else r.h // 2
                br = pygame.Rect(r.x, r.bottom - hh, r.w, hh)
                pygame.draw.rect(S, (172, 92, 62), br)
                for i, yy in enumerate(range(br.top + 4, br.bottom, 5)):
                    pygame.draw.line(S, (130, 70, 50), (br.left, yy), (br.right - 1, yy))
            elif p < 0.4:
                pygame.draw.rect(S, (60, 100, 185), r)
                for yy in range(r.top + 4, r.bottom, 6):
                    pygame.draw.line(S, (80, 125, 210), (r.left, yy), (r.right - 1, yy + 2))
            elif p < 0.5:
                pygame.draw.rect(S, (85, 140, 95), r)
            elif p < 0.56:
                pygame.draw.line(S, (30, 30, 30), (r.centerx, r.top), (r.centerx, r.top + 9))
                pygame.draw.circle(S, (255, 230, 140), (r.centerx, r.top + 11), 3)
    for fy in rows:
        pygame.draw.rect(S, concrete, (body.left, fy, BODY_W, 7))
        pygame.draw.line(S, shade(concrete, 0.75), (body.left, fy + 6), (body.right - 1, fy + 6))
    for x in (body.left, body.centerx - 3, body.right - 7):
        pygame.draw.rect(S, shade(concrete, 0.92), (x, body.top, 7, body.h))
    if len(rows) > 1:
        fy = rows[1]
        sign = pygame.Rect(body.left + 4, fy + 9, BODY_W - 8, 22)
        pygame.draw.rect(S, (200, 30, 40), sign)
        pygame.draw.rect(S, (255, 255, 255), sign, 1)
        t = text_surf(rng.choice(["იყიდება", "ბინები", "ჩაბარდება 2019"]), 13, (255, 255, 255), None, 0)
        if t.get_width() > sign.w - 4:
            t = pygame.transform.smoothscale(t, (sign.w - 4, t.get_height()))
        S.blit(t, t.get_rect(center=sign.center))
    return concrete


def draw_dish(S, x, y, big=False):
    w = 12 if big else 9
    pygame.draw.ellipse(S, (238, 238, 240), (x, y, w, w + 1))
    pygame.draw.ellipse(S, (160, 160, 165), (x, y, w, w + 1), 1)
    pygame.draw.line(S, (120, 120, 125), (x + w // 2, y + w // 2), (x + w + 2, y + w // 2 + 2), 1)


def facade_soviet(S, body, rng, hanging):
    """თბილისური საბჭოთა კორპუსი: ყოველ სართულზე სხვადასხვანაირად შეშუშული აივნები და თეფშები."""
    wall = rng.choice([(196, 186, 166), (178, 172, 160), (205, 192, 170), (168, 164, 156)])
    pygame.draw.rect(S, wall, body)
    rows = floor_rows(body, hanging)
    slab = shade(wall, 0.82)
    for fy in rows:
        pygame.draw.rect(S, slab, (body.left, fy + FLOOR - 5, BODY_W, 4))
        for wx in (body.left + 4, body.left + 34, body.left + 64):
            cell = pygame.Rect(wx, fy + 4, 25, FLOOR - 9)
            p = rng.random()
            if p < 0.4:      # შეშუშული აივანი
                fr = rng.choice([(235, 235, 230), (235, 235, 230), (150, 110, 80), (120, 150, 175)])
                pygame.draw.rect(S, fr, cell)
                pygame.draw.rect(S, rng.choice([(80, 100, 120), (110, 130, 150), (250, 220, 130)]),
                                 (cell.x + 2, cell.y + 2, cell.w - 4, cell.h // 2))
                for px in range(cell.x + 6, cell.right - 2, 6):
                    pygame.draw.line(S, fr, (px, cell.y + 2), (px, cell.y + cell.h // 2 + 1))
                pygame.draw.rect(S, shade(fr, 0.85), (cell.x, cell.y + cell.h // 2 + 2, cell.w, cell.h // 2 - 2))
            elif p < 0.75:   # ღია აივანი
                pygame.draw.rect(S, (55, 58, 66), cell)
                pygame.draw.rect(S, shade(wall, 0.9), (cell.x, cell.bottom - 9, cell.w, 9))
                for px in range(cell.x + 2, cell.right, 4):
                    pygame.draw.line(S, shade(wall, 0.7), (px, cell.bottom - 9), (px, cell.bottom - 1))
                if rng.random() < 0.45:
                    draw_laundry(S, cell.x + 1, cell.right - 1, cell.y + 3, rng)
            else:            # ფანჯარა
                draw_window(S, pygame.Rect(cell.x + 3, cell.y + 3, 19, 18), rng)
            if rng.random() < 0.22:
                draw_dish(S, cell.right - 8, cell.y + rng.randint(0, 6), rng.random() < 0.3)
    add_kerzebi(S, body, rows, rng, rng.randint(0, 2))
    return wall


def facade_pink(S, body, rng, hanging):
    """ბეჟი კორპუსი ვარდისფერი ზოლებით, თეთრი ჩარჩოებით და აივნის კიბის ბლოკით."""
    wall = rng.choice([(226, 206, 160), (230, 214, 178)])
    band = rng.choice([(222, 140, 130), (214, 120, 112), (200, 150, 120)])
    pygame.draw.rect(S, wall, body)
    rows = floor_rows(body, hanging)
    stair = pygame.Rect(body.left + 30, body.top, 18, body.h)
    for fy in rows:
        pygame.draw.rect(S, band, (body.left, fy + 6, BODY_W, FLOOR - 14))
        for wx in (body.left + 5, body.left + 52, body.left + 72):
            draw_window(S, pygame.Rect(wx, fy + 7, 16, FLOOR - 16), rng, frame=(245, 245, 240))
        if rng.random() < 0.15:
            draw_ac(S, body.left + rng.choice((6, 54)), fy + FLOOR - 12)
    pygame.draw.rect(S, (240, 236, 226), stair)
    for fy in rows:
        pygame.draw.rect(S, (90, 95, 105), (stair.x + 4, fy + 9, 10, FLOOR - 18))
    add_kerzebi(S, body, rows, rng, rng.randint(0, 2))
    return wall


def facade_unfinished(S, body, rng, hanging):
    """დაწყებული და დაუმთავრებელი: ნაცრისფერი ბლოკი, მინის გარეშე ფანჯრები, ყვითელი გაზის მილი, ხარაჩო."""
    wall = rng.choice([(176, 176, 172), (168, 166, 160), (184, 182, 176)])
    pygame.draw.rect(S, wall, body)
    for _ in range(140):
        x = rng.randint(body.left, body.right - 4)
        y = rng.randint(max(body.top, 0), body.bottom - 4)
        pygame.draw.rect(S, shade(wall, rng.choice((0.9, 1.06))), (x, y, 3, 2))
    rows = floor_rows(body, hanging)
    for fy in rows:
        pygame.draw.line(S, shade(wall, 0.85), (body.left, fy), (body.right - 1, fy))
        for i, wx in enumerate((body.left + 8, body.left + 36, body.left + 64)):
            op = pygame.Rect(wx, fy + 7, 18, FLOOR - 14)
            pygame.draw.rect(S, (38, 38, 40), op)
            if rng.random() < 0.3:
                pygame.draw.rect(S, (60, 60, 64), (op.x - 4, op.bottom - 2, op.w + 8, 3))
                for px in range(op.x - 3, op.right + 4, 4):
                    pygame.draw.line(S, (70, 70, 74), (px, op.bottom - 9), (px, op.bottom - 2))
    gx = body.left + rng.choice((29, 57))
    pygame.draw.line(S, (235, 190, 40), (gx, body.top), (gx, body.bottom), 3)
    if rng.random() < 0.7:     # წითელი ხარაჩო
        left = rng.random() < 0.5
        sx = body.left - 12 if left else body.right
        for fy in rows[:14]:
            pygame.draw.line(S, (200, 70, 50), (sx, fy), (sx + 12, fy), 2)
            pygame.draw.line(S, (200, 70, 50), (sx, fy), (sx + 12, fy + FLOOR), 1)
        pygame.draw.line(S, (200, 70, 50), (sx, body.top), (sx, body.bottom), 2)
        pygame.draw.line(S, (200, 70, 50), (sx + 12, body.top), (sx + 12, body.bottom), 2)
    if len(rows) > 2 and rng.random() < 0.6:
        fy = rows[2]
        sign = pygame.Rect(body.left + 4, fy + 8, BODY_W - 8, 20)
        pygame.draw.rect(S, (30, 70, 160), sign)
        t = text_surf(rng.choice(["ჩაბარდება 2017", "იყიდება", "მწვანე კარკასი"]), 12, (255, 255, 255), None, 0)
        if t.get_width() > sign.w - 4:
            t = pygame.transform.smoothscale(t, (sign.w - 4, t.get_height()))
        S.blit(t, t.get_rect(center=sign.center))
    return wall


STYLES = [facade_soviet, facade_soviet, facade_pink, facade_unfinished, facade_unfinished, facade_karkasi,
          facade_panel, facade_khrush, facade_tower]


def draw_roof(S, body, rng, style, wall):
    top = body.top
    pygame.draw.rect(S, shade(wall, 0.62), (body.left - 2, top - 4, BODY_W + 4, 6))
    if style is facade_karkasi or style is facade_unfinished:
        for x in range(body.left + 2, body.right, 5):
            pygame.draw.line(S, (140, 80, 50), (x, top - 3), (x + rng.randint(-2, 2), top - rng.randint(8, 18)), 1)
        for x in (body.left, body.centerx - 3, body.right - 7):
            pygame.draw.rect(S, (150, 146, 138), (x, top - 14, 7, 12))
        return
    if style is facade_tower and rng.random() < 0.6:
        cx = body.centerx
        pygame.draw.polygon(S, (200, 165, 70), [(body.left + 8, top - 4), (body.right - 8, top - 4),
                                                (cx + 14, top - 24), (cx - 14, top - 24)])
        pygame.draw.line(S, (90, 90, 95), (cx, top - 24), (cx, top - 44), 2)
        pygame.draw.circle(S, (230, 50, 50), (cx, top - 44), 2)
        return
    x = body.left + 2
    tries = 0
    while x < body.right - 12 and tries < 4:
        tries += 1
        kind = rng.choice(["antenna", "dish", "tank", "shack", "billboard", "none"])
        if kind == "antenna":
            pygame.draw.line(S, (70, 70, 75), (x + 5, top - 4), (x + 5, top - 34), 1)
            for i, wdt in enumerate((12, 9, 6)):
                y = top - 28 + i * 6
                pygame.draw.line(S, (70, 70, 75), (x + 5 - wdt // 2, y), (x + 5 + wdt // 2, y), 1)
            x += 14
        elif kind == "dish":
            pygame.draw.line(S, (90, 90, 95), (x + 7, top - 4), (x + 7, top - 12), 2)
            pygame.draw.ellipse(S, (225, 225, 228), (x, top - 22, 15, 13))
            pygame.draw.ellipse(S, (150, 150, 155), (x, top - 22, 15, 13), 1)
            x += 18
        elif kind == "tank":
            pygame.draw.rect(S, (60, 115, 175), (x, top - 20, 18, 16))
            pygame.draw.ellipse(S, (90, 145, 200), (x, top - 24, 18, 8))
            x += 22
        elif kind == "shack":
            col = rng.choice(KERZ_COLS)
            pygame.draw.rect(S, col, (x, top - 20, 28, 16))
            pygame.draw.rect(S, (70, 95, 120), (x + 9, top - 15, 9, 8))
            pygame.draw.line(S, (110, 110, 115), (x - 2, top - 19), (x + 30, top - 24), 3)
            x += 32
        elif kind == "billboard" and body.right - x > 62:
            pygame.draw.line(S, (60, 60, 60), (x + 10, top - 4), (x + 10, top - 14), 2)
            pygame.draw.line(S, (60, 60, 60), (x + 50, top - 4), (x + 50, top - 14), 2)
            board = pygame.Rect(x, top - 38, 62, 24)
            pygame.draw.rect(S, rng.choice([(200, 35, 45), (30, 90, 170), (240, 180, 30)]), board)
            pygame.draw.rect(S, (250, 250, 250), board, 1)
            t = text_surf(rng.choice(SIGNS), 13, (255, 255, 255), (30, 20, 20), 1)
            if t.get_width() > board.w - 2:
                t = pygame.transform.smoothscale(t, (board.w - 2, t.get_height()))
            S.blit(t, t.get_rect(center=board.center))
            x += 66
        else:
            x += 12


def draw_underside(S, body, rng, wall):
    b = body.bottom
    pygame.draw.rect(S, shade(wall, 0.6), (body.left - 3, b - 6, BODY_W + 6, 7))
    for _ in range(rng.randint(1, 3)):
        x1 = rng.randint(body.left, body.right)
        x2 = clamp(x1 + rng.randint(-40, 40), body.left - 10, body.right + 10)
        sag = rng.randint(8, UNDER_M - 4)
        p1 = (x1, b)
        p2 = (x2, b)
        c = ((x1 + x2) / 2, b + sag * 2)
        pts = [bezier(p1, c, p2, t / 10) for t in range(11)]
        pygame.draw.lines(S, (25, 25, 25), False, pts, 1)
    r = rng.random()
    if r < 0.35:
        draw_laundry(S, body.left + 6, body.right - 6, b + 3, rng)
    elif r < 0.6:
        draw_ac(S, rng.randint(body.left + 4, body.right - 18), b + 2)
    elif r < 0.8:
        k = pygame.Rect(rng.randint(body.left - 6, body.right - 24), b, 30, UNDER_M - 6)
        draw_kerz(S, k, body, rng)


BUILDING_POOL = []


class Building:
    def __init__(self, x, gap_c, gap, rng, moving, amp, freq):
        self.x = float(x)
        self.base_c = gap_c
        self.gap = gap
        self.moving = moving
        self.amp = amp
        self.freq = freq
        self.phase = rng.uniform(0, math.tau)
        self.t = 0.0
        self.passed = False
        self.bottom_surf, self.top_surf = rng.choice(BUILDING_POOL)
        self.width = BODY_W + DECOR_M * 2

    @staticmethod
    def render(rng):
        sw = BODY_W + DECOR_M * 2
        style = rng.choice(STYLES)
        bottom = pygame.Surface((sw, ROOF_M + H), pygame.SRCALPHA)
        body = pygame.Rect(DECOR_M, ROOF_M, BODY_W, H)
        wall = style(bottom, body, rng, False)
        pygame.draw.rect(bottom, shade(wall, 0.55), body, 2)
        draw_roof(bottom, body, rng, style, wall)

        style2 = style if rng.random() < 0.5 else rng.choice(STYLES)
        top = pygame.Surface((sw, H + UNDER_M), pygame.SRCALPHA)
        body = pygame.Rect(DECOR_M, 0, BODY_W, H)
        wall = style2(top, body, rng, True)
        pygame.draw.rect(top, shade(wall, 0.55), body, 2)
        draw_underside(top, body, rng, wall)
        return bottom.convert_alpha(), top.convert_alpha()

    @property
    def gap_c(self):
        if self.moving:
            return self.base_c + self.amp * math.sin(self.phase + self.t * self.freq)
        return self.base_c

    def update(self, dt, speed):
        self.x -= speed * dt
        self.t += dt

    def rects(self):
        gc = self.gap_c
        top_b = gc - self.gap / 2
        bot_t = gc + self.gap / 2
        bx = int(self.x) + DECOR_M
        return (pygame.Rect(bx, -2000, BODY_W, int(top_b) + 2000),
                pygame.Rect(bx, int(bot_t), BODY_W, 3000))

    def draw(self, surf):
        gc = self.gap_c
        surf.blit(self.top_surf, (int(self.x), int(gc - self.gap / 2 - H)))
        surf.blit(self.bottom_surf, (int(self.x), int(gc + self.gap / 2 - ROOF_M)))


# ----------------------------------------------------------------------------
# თბილისის უბნები (ფონი)
# ----------------------------------------------------------------------------
DISTRICTS = [
    dict(name="ძველი თბილისი", kind="old", sky=((110, 170, 232), (255, 214, 172)),
         body=("sun", (255, 244, 205), (370, 230), 34), cloud=(255, 246, 236),
         far=(126, 140, 112), mid=(158, 126, 100), dim=0),
    dict(name="ვაკე", kind="vake", sky=((80, 155, 230), (195, 228, 250)),
         body=("sun", (255, 255, 228), (90, 160), 30), cloud=(255, 255, 255),
         far=(112, 146, 118), mid=(178, 160, 138), dim=0),
    dict(name="საბურთალო", kind="saburtalo", sky=((70, 140, 220), (178, 216, 245)),
         body=("sun", (255, 255, 230), (400, 120), 28), cloud=(250, 252, 255),
         far=(132, 150, 168), mid=(146, 152, 166), dim=0),
    dict(name="დიდუბე", kind="didube", sky=((118, 150, 212), (252, 206, 150)),
         body=("sun", (255, 236, 180), (330, 330), 34), cloud=(255, 236, 220),
         far=(146, 132, 140), mid=(128, 118, 122), dim=10),
    dict(name="გლდანი", kind="gldani", sky=((236, 118, 90), (255, 204, 132)),
         body=("sun", (255, 224, 150), (240, 520), 52), cloud=(255, 196, 170),
         far=(150, 92, 100), mid=(112, 76, 88), dim=30),
    dict(name="ვარკეთილი", kind="varketili", sky=((58, 48, 108), (232, 122, 112)),
         body=("moon", (250, 246, 222), (110, 150), 22), cloud=(160, 120, 150),
         far=(74, 58, 94), mid=(56, 46, 76), dim=70, night=True),
    dict(name="მთაწმინდა", kind="mtatsminda", sky=((10, 15, 42), (52, 46, 98)),
         body=("moon", (250, 248, 230), (360, 140), 24), cloud=(70, 70, 110),
         far=(26, 26, 52), mid=(36, 30, 60), dim=105, night=True, stars=True),
]


def hill_points(base, comps, step=8):
    pts = [(0, LAYER_H)]
    for x in range(0, LW + step, step):
        pts.append((x, hill_y(x, base, comps)))
    pts.append((LW, LAYER_H))
    return pts


def hill_y(x, base, comps):
    return base - sum(a * math.sin(2 * math.pi * k * x / LW + p) for a, k, p in comps)


def place(S, fn, x, rng, *args):
    seed = rng.random()
    for ox in (-LW, 0, LW):
        fn(S, x + ox, *args, r=random.Random(seed))


def f_church(S, x, gy, col, s, night, r):
    d = shade(col, 0.82)
    pygame.draw.rect(S, col, (x - 16 * s, gy - 30 * s, 32 * s, 30 * s))
    pygame.draw.rect(S, d, (x - 26 * s, gy - 20 * s, 12 * s, 20 * s))
    pygame.draw.rect(S, col, (x - 7 * s, gy - 46 * s, 14 * s, 17 * s))
    pygame.draw.polygon(S, d, [(x - 9 * s, gy - 46 * s), (x + 9 * s, gy - 46 * s), (x, gy - 64 * s)])
    pygame.draw.line(S, d, (x, gy - 64 * s), (x, gy - 72 * s), max(1, int(2 * s)))
    pygame.draw.line(S, d, (x - 3 * s, gy - 69 * s), (x + 3 * s, gy - 69 * s), max(1, int(2 * s)))
    if night:
        for i in range(2):
            pygame.draw.rect(S, (250, 215, 120), (x - 3 * s, gy - 42 * s + i * 0, 2 * s, 7 * s))


def f_fortress(S, x, gy, col, s, night, r):
    d = shade(col, 0.85)
    pygame.draw.rect(S, col, (x - 70 * s, gy - 22 * s, 140 * s, 22 * s))
    for cx in range(int(x - 70 * s), int(x + 70 * s), int(9 * s)):
        pygame.draw.rect(S, col, (cx, gy - 27 * s, 5 * s, 6 * s))
    for tx, th in ((-70, 46), (-10, 36), (48, 56)):
        tr = pygame.Rect(x + tx * s, gy - th * s, 22 * s, th * s)
        pygame.draw.rect(S, d, tr)
        for cx in range(tr.left, tr.right, int(7 * s)):
            pygame.draw.rect(S, d, (cx, tr.top - 5 * s, 4 * s, 6 * s))
    if night:
        for tx in (-60, 0, 58):
            pygame.draw.circle(S, (255, 210, 120), (int(x + tx * s), int(gy - 12 * s)), 2)


def f_tv_tower(S, x, gy, col, s, night, r):
    hgt = 120 * s
    pygame.draw.line(S, col, (x - 18 * s, gy), (x - 3 * s, gy - hgt), 2)
    pygame.draw.line(S, col, (x + 18 * s, gy), (x + 3 * s, gy - hgt), 2)
    n = 8
    for i in range(n):
        t0, t1 = i / n, (i + 1) / n
        xa0, xa1 = lerp(x - 18 * s, x - 3 * s, t0), lerp(x - 18 * s, x - 3 * s, t1)
        xb0, xb1 = lerp(x + 18 * s, x + 3 * s, t0), lerp(x + 18 * s, x + 3 * s, t1)
        pygame.draw.line(S, col, (xa0, gy - hgt * t0), (xb1, gy - hgt * t1), 1)
        pygame.draw.line(S, col, (xb0, gy - hgt * t0), (xa1, gy - hgt * t1), 1)
    pygame.draw.rect(S, col, (x - 14 * s, gy - 82 * s, 28 * s, 8 * s))
    pygame.draw.rect(S, col, (x - 9 * s, gy - hgt - 4 * s, 18 * s, 6 * s))
    pygame.draw.line(S, col, (x, gy - hgt), (x, gy - hgt - 40 * s), 2)
    if night:
        for i in range(9):
            t = i / 8
            pygame.draw.circle(S, (255, 255, 230), (int(x - 18 * s + 15 * s * t), int(gy - hgt * t)), 1)
            pygame.draw.circle(S, (255, 255, 230), (int(x + 18 * s - 15 * s * t), int(gy - hgt * t)), 1)
        pygame.draw.circle(S, (255, 60, 60), (int(x), int(gy - hgt - 40 * s)), 3)
        pygame.draw.circle(S, (255, 60, 60), (int(x), int(gy - 82 * s)), 2)


def f_ferris(S, x, gy, col, s, night, r):
    R = 26 * s
    cy = gy - 36 * s
    pygame.draw.line(S, col, (x - 14 * s, gy), (x, cy), 2)
    pygame.draw.line(S, col, (x + 14 * s, gy), (x, cy), 2)
    pygame.draw.circle(S, col, (int(x), int(cy)), int(R), 2)
    for i in range(10):
        a = i * math.tau / 10
        ex, ey = x + math.cos(a) * R, cy + math.sin(a) * R
        pygame.draw.line(S, col, (x, cy), (ex, ey), 1)
        c = [(255, 90, 90), (255, 220, 90), (120, 220, 255), (180, 255, 140)][i % 4] if night else col
        pygame.draw.rect(S, c, (ex - 2, ey, 5, 5))


def f_block(S, x, gy, col, s, night, w=None, h=None, label=None, r=None):
    w = w or r.randint(60, 110)
    h = h or r.randint(90, 190)
    rect = pygame.Rect(x, gy - h, w, h)
    pygame.draw.rect(S, col, rect)
    wc = shade(col, 0.8)
    for yy in range(rect.top + 8, rect.bottom - 6, 12):
        for xx in range(rect.left + 5, rect.right - 6, 10):
            if night:
                c = (250, 214, 120) if r.random() < 0.35 else shade(col, 0.7)
            else:
                c = wc
            pygame.draw.rect(S, c, (xx, yy, 5, 6))
    if r.random() < 0.6:
        for _ in range(r.randint(1, 3)):
            kx = r.choice((rect.left - 6, rect.right - 6))
            ky = r.randint(rect.top + 10, rect.bottom - 30)
            pygame.draw.rect(S, shade(col, 1.12), (kx, ky, 12, 14))
    if label:
        t = text_surf(label, 30, shade(col, 1.35), None, 0)
        S.blit(t, t.get_rect(center=(rect.centerx, rect.top + 30)))


def f_tower(S, x, gy, col, s, night, r):
    w = r.randint(30, 46)
    h = r.randint(180, 280)
    c = shade(col, 1.06)
    pygame.draw.rect(S, c, (x, gy - h, w, h))
    for yy in range(gy - h + 6, gy, 9):
        pygame.draw.line(S, shade(c, 1.15), (x, yy), (x + w - 1, yy))
        if night:
            for xx in range(x + 3, x + w - 4, 7):
                if r.random() < 0.3:
                    pygame.draw.rect(S, (250, 214, 120), (xx, yy + 2, 4, 5))
    pygame.draw.line(S, c, (x + w // 2, gy - h), (x + w // 2, gy - h - 16), 2)


def f_oldhouse(S, x, gy, col, s, night, r):
    w = r.randint(46, 76)
    h = r.randint(56, 96)
    accents = [(210, 150, 120), (180, 170, 120), (150, 170, 175), (200, 180, 150), (190, 120, 110)]
    c = lerp_col(r.choice(accents), col, 0.55)
    rect = pygame.Rect(x, gy - h, w, h)
    pygame.draw.rect(S, c, rect)
    roof = lerp_col((170, 80, 60), col, 0.5)
    pygame.draw.polygon(S, roof, [(x - 4, gy - h), (x + w + 4, gy - h), (x + w - 8, gy - h - 14), (x + 8, gy - h - 14)])
    bal = lerp_col((110, 72, 45), col, 0.4)
    by = gy - h + 22
    pygame.draw.rect(S, bal, (x - 3, by, w + 6, 16))
    for xx in range(x, x + w, 5):
        pygame.draw.line(S, shade(bal, 1.3), (xx, by + 2), (xx, by + 14))
    pygame.draw.line(S, shade(bal, 0.7), (x - 3, by), (x + w + 3, by), 2)
    for xx in range(x + 6, x + w - 10, 14):
        wc = (250, 214, 120) if night and r.random() < 0.5 else shade(c, 0.7)
        pygame.draw.rect(S, wc, (xx, by + 24, 8, 12))
        pygame.draw.circle(S, wc, (xx + 4, by + 24), 4)


def f_baths(S, x, gy, col, s, night, r):
    c = lerp_col((175, 110, 80), col, 0.5)
    for i in range(3):
        cx = x + i * 30
        pygame.draw.circle(S, c, (cx, gy), 14, draw_top_left=True, draw_top_right=True)
        pygame.draw.circle(S, shade(c, 0.8), (cx, gy), 14, 2, draw_top_left=True, draw_top_right=True)
        pygame.draw.rect(S, shade(c, 0.85), (cx - 2, gy - 20, 4, 7))


def f_tree(S, x, gy, col, s, night, r):
    tc = lerp_col((70, 120, 60), col, 0.5) if not night else shade(col, 1.2)
    pygame.draw.line(S, shade(col, 0.7), (x, gy), (x, gy - 18), 3)
    for _ in range(3):
        pygame.draw.circle(S, tc, (x + r.randint(-8, 8), gy - 22 - r.randint(0, 10)), r.randint(9, 13))


def f_stalin(S, x, gy, col, s, night, r):
    w = r.randint(90, 130)
    h = r.randint(90, 130)
    c = lerp_col((215, 180, 130), col, 0.5)
    rect = pygame.Rect(x, gy - h, w, h)
    pygame.draw.rect(S, c, rect)
    pygame.draw.rect(S, shade(c, 1.1), (x - 3, gy - h - 5, w + 6, 6))
    pygame.draw.rect(S, c, (x + w // 2 - 12, gy - h - 26, 24, 22))
    pygame.draw.polygon(S, shade(c, 0.9), [(x + w // 2 - 14, gy - h - 26), (x + w // 2 + 14, gy - h - 26), (x + w // 2, gy - h - 40)])
    for xx in range(x + 6, x + w - 6, 12):
        pygame.draw.rect(S, shade(c, 1.12), (xx, gy - 24, 5, 24))
    for yy in range(gy - h + 10, gy - 30, 16):
        for xx in range(x + 8, x + w - 10, 14):
            wc = (250, 214, 120) if night and r.random() < 0.4 else shade(c, 0.72)
            pygame.draw.rect(S, wc, (xx, yy, 7, 10))


def f_metro(S, x, gy, col, s, night, r):
    pygame.draw.line(S, (80, 80, 85), (x, gy), (x, gy - 40), 3)
    pygame.draw.circle(S, (205, 40, 45), (x, gy - 48), 11)
    t = text_surf("M", 16, (255, 255, 255), None, 0)
    S.blit(t, t.get_rect(center=(x, gy - 49)))


def f_kiosk(S, x, gy, col, s, night, r):
    c = lerp_col(r.choice([(220, 190, 80), (90, 150, 200), (200, 90, 80)]), col, 0.45)
    pygame.draw.rect(S, c, (x, gy - 26, 34, 26))
    pygame.draw.rect(S, shade(c, 1.2), (x - 3, gy - 30, 40, 6))
    pygame.draw.rect(S, (250, 214, 120) if night else shade(c, 0.7), (x + 5, gy - 20, 24, 10))


def f_mountains(S, x, gy, col, s, night, r):
    pts = [(x, gy)]
    xx = x
    while xx < x + 320:
        xx += r.randint(25, 55)
        pts.append((xx, gy - r.randint(50, 120)))
        xx += r.randint(20, 40)
        pts.append((xx, gy - r.randint(20, 50)))
    pts.append((xx, gy))
    pygame.draw.polygon(S, col, pts)
    for i in range(1, len(pts) - 1, 2):
        px, py = pts[i]
        if gy - py > 70:
            pygame.draw.polygon(S, (240, 242, 248), [(px, py), (px - 9, py + 14), (px + 9, py + 14)])


def make_sky(d, rng):
    S = pygame.Surface((W, H))
    top, bot = d["sky"]
    for y in range(H):
        pygame.draw.line(S, lerp_col(top, bot, clamp(y / (GROUND_Y), 0, 1)), (0, y), (W, y))
    if d.get("stars"):
        for _ in range(140):
            b = rng.randint(140, 255)
            S.set_at((rng.randint(0, W - 1), rng.randint(0, int(H * 0.6))), (b, b, b))
        for _ in range(12):
            x, y = rng.randint(0, W - 1), rng.randint(0, int(H * 0.5))
            pygame.draw.circle(S, (255, 255, 240), (x, y), 1)
    kind, col, pos, rad = d["body"]
    glow = pygame.Surface((rad * 8, rad * 8), pygame.SRCALPHA)
    for i in range(10, 0, -1):
        pygame.draw.circle(glow, (*col, 9), (rad * 4, rad * 4), int(rad * (1 + i * 0.3)))
    S.blit(glow, (pos[0] - rad * 4, pos[1] - rad * 4))
    disk = pygame.Surface((rad * 2 + 2, rad * 2 + 2), pygame.SRCALPHA)
    pygame.draw.circle(disk, col, (rad + 1, rad + 1), rad)
    if kind == "moon":
        pygame.draw.circle(disk, (0, 0, 0, 0), (rad + 1 + rad // 2, rad + 1 - rad // 4), rad)
    S.blit(disk, (pos[0] - rad - 1, pos[1] - rad - 1))
    return S.convert()


def make_clouds(d, rng):
    S = pygame.Surface((LW, 360), pygame.SRCALPHA)
    a = 120 if d.get("night") else 200
    col = (*d["cloud"], a)

    def cloud(S, x, r):
        y = r.randint(30, 300)
        for _ in range(r.randint(4, 7)):
            pygame.draw.circle(S, col, (x + r.randint(-40, 40), y + r.randint(-10, 8)), r.randint(16, 30))

    for i in range(7):
        place(S, cloud, i * (LW // 7) + rng.randint(0, 60), rng)
    return S.convert_alpha()


def make_far(d, rng):
    S = pygame.Surface((LW, LAYER_H), pygame.SRCALPHA)
    col = d["far"]
    night = d.get("night", False)
    k = d["kind"]
    comps = [(rng.randint(20, 45), 2, rng.uniform(0, 6)), (rng.randint(10, 25), 5, rng.uniform(0, 6)),
             (rng.randint(4, 10), 11, rng.uniform(0, 6))]
    base = LAYER_H - 140
    if k == "saburtalo":
        place(S, f_mountains, 40, rng, LAYER_H - 230, shade(col, 1.15), 1, night)
        place(S, f_mountains, 520, rng, LAYER_H - 230, shade(col, 1.15), 1, night)
        base = LAYER_H - 110
    if k == "mtatsminda":
        comps = [(90, 1, 0.3), (20, 3, 1.0), (6, 9, 2.0)]
        base = LAYER_H - 200
    pygame.draw.polygon(S, col, hill_points(base, comps))
    fc = shade(col, 0.88)

    def on_hill(x):
        return int(hill_y(x, base, comps)) + 4

    if k == "old":
        place(S, f_fortress, 260, rng, on_hill(260), fc, 1.0, night)
        place(S, f_church, 640, rng, on_hill(640), fc, 1.0, night)
        x1, x2 = 330, 520
        pygame.draw.line(S, shade(col, 0.6), (x1, on_hill(x1) - 20), (x2, on_hill(x2) + 60), 1)
        mx, my = (x1 + x2) // 2, (on_hill(x1) - 20 + on_hill(x2) + 60) // 2
        pygame.draw.line(S, shade(col, 0.6), (mx, my), (mx, my + 6), 1)
        pygame.draw.rect(S, (200, 70, 60), (mx - 5, my + 6, 10, 8))
        place(S, f_tv_tower, 860, rng, on_hill(860), shade(col, 0.8), 0.6, night)
    elif k == "vake":
        for i in range(14):
            x = i * 70 + rng.randint(0, 30)
            place(S, f_tree, x, rng, on_hill(x), fc, 1, night)
        place(S, f_tv_tower, 300, rng, on_hill(300), shade(col, 0.8), 0.7, night)
    elif k == "saburtalo":
        for i in range(6):
            x = i * 160 + rng.randint(0, 60)
            place(S, f_tower, x, rng, on_hill(x) + 10, fc, 1, night)
    elif k == "didube":
        place(S, f_tv_tower, 520, rng, on_hill(520), fc, 0.8, night)
        place(S, f_church, 180, rng, on_hill(180), fc, 0.8, night)
    elif k in ("gldani", "varketili"):
        for i in range(9):
            x = i * 105 + rng.randint(0, 40)
            place(S, f_block, x, rng, on_hill(x) + 12, fc, 1, night, rng.randint(50, 80), rng.randint(50, 100))
    elif k == "mtatsminda":
        top_x = int(LW * 0.25)
        place(S, f_tv_tower, top_x, rng, on_hill(top_x), shade(col, 2.6), 1.3, night)
        place(S, f_ferris, top_x + 120, rng, on_hill(top_x + 120), shade(col, 2.6), 1.0, night)
        place(S, f_church, top_x - 140, rng, on_hill(top_x - 140), shade(col, 1.5), 0.8, night)
        for _ in range(120):
            x = rng.randint(0, LW - 1)
            y = rng.randint(int(on_hill(x)) + 10, LAYER_H - 2)
            S.set_at((x, y), (255, 220, 140))
    return S.convert_alpha()


def make_mid(d, rng):
    S = pygame.Surface((LW, LAYER_H), pygame.SRCALPHA)
    col = d["mid"]
    night = d.get("night", False)
    k = d["kind"]
    gy = LAYER_H
    if k == "old":
        x = 0
        while x < LW - 40:
            place(S, f_oldhouse, x, rng, gy, col, 1, night)
            x += rng.randint(50, 80)
        place(S, f_baths, 380, rng, gy, col, 1, night)
        place(S, f_church, 720, rng, gy - 70, col, 1.3, night)
    elif k == "vake":
        x = 0
        while x < LW - 60:
            place(S, f_stalin, x, rng, gy, col, 1, night)
            x += rng.randint(120, 160)
            place(S, f_tree, x - 10, rng, gy, col, 1, night)
    elif k == "saburtalo":
        x = 0
        while x < LW - 40:
            if rng.random() < 0.4:
                place(S, f_tower, x, rng, gy, col, 1, night)
                x += 50
            else:
                place(S, f_block, x, rng, gy, col, 1, night)
                x += rng.randint(70, 110)
    elif k == "didube":
        x = 0
        while x < LW - 40:
            place(S, f_block, x, rng, gy - 20, col, 1, night, None, rng.randint(80, 140))
            x += rng.randint(90, 120)
        for i in range(10):
            place(S, f_kiosk, i * 96 + rng.randint(0, 40), rng, gy, col, 1, night)
        place(S, f_metro, 300, rng, gy, col, 1, night)
    elif k == "gldani":
        x = 0
        n = 1
        while x < LW - 100:
            w = rng.randint(120, 170)
            place(S, f_block, x, rng, gy, col, 1, night, w, rng.randint(130, 200), str(n))
            x += w + rng.randint(15, 30)
            n += 1
    elif k == "varketili":
        x = 0
        while x < LW - 60:
            w = rng.randint(80, 140)
            place(S, f_block, x, rng, gy, col, 1, night, w, rng.randint(110, 190))
            x += w + rng.randint(10, 25)
    elif k == "mtatsminda":
        x = 0
        while x < LW - 40:
            place(S, f_oldhouse, x, rng, gy, col, 1, night)
            x += rng.randint(55, 85)
    return S.convert_alpha()


def make_ground(rng):
    S = pygame.Surface((LW, GROUND_H))
    S.fill((62, 62, 68))
    pygame.draw.rect(S, (120, 118, 112), (0, 0, LW, 6))
    pygame.draw.rect(S, (178, 172, 162), (0, 6, LW, 18))
    for x in range(0, LW, 24):
        pygame.draw.line(S, (150, 145, 136), (x, 6), (x, 23))
    pygame.draw.rect(S, (205, 205, 198), (0, 24, LW, 5))
    for _ in range(900):
        c = rng.randint(50, 80)
        S.set_at((rng.randint(0, LW - 1), rng.randint(30, GROUND_H - 1)), (c, c, c + 4))
    for x in range(0, LW, 80):
        pygame.draw.rect(S, (230, 230, 225), (x + 20, 60, 40, 5))
    for i in range(4):
        x = rng.randint(40, LW - 80)
        y = rng.randint(34, 80)
        w = rng.randint(22, 40)
        pygame.draw.ellipse(S, (95, 95, 100), (x - 2, y - 2, w + 4, 14))
        pygame.draw.ellipse(S, (36, 36, 40), (x, y, w, 10))
    mx = rng.randint(100, LW - 100)
    pygame.draw.circle(S, (85, 85, 92), (mx, 46), 10)
    pygame.draw.circle(S, (50, 50, 56), (mx, 46), 10, 2)
    for i in range(-6, 7, 4):
        pygame.draw.line(S, (50, 50, 56), (mx - 7, 46 + i // 2), (mx + 7, 46 + i // 2))
    return S.convert()


# ----------------------------------------------------------------------------
# ხმა (პროცედურული)
# ----------------------------------------------------------------------------
class Audio:
    def __init__(self):
        self.ok = False
        self.muted = False
        self.sounds = {}
        self.music = None
        self.music_started = False
        self.music_channel = None
        try:
            init = pygame.mixer.get_init()
            if not init:
                return
            self.sr, _, self.ch = init
            self.ok = True
        except Exception:
            return
        sr = self.sr
        self.sounds["flap"] = self.make(self.sweep(280, 640, 0.09, noise=0.3, decay=4), 0.32)
        self.sounds["coin"] = self.make(self.pluck(1318, 0.08) + self.pluck(1760, 0.22), 0.32)
        self.sounds["point"] = self.make(self.pluck(880, 0.1), 0.18)
        self.sounds["hit"] = self.make(self.mix(self.sweep(160, 50, 0.32, noise=0.7, decay=7)), 0.55)
        self.sounds["die"] = self.make(self.sweep(520, 110, 0.6, square=True, decay=1.5), 0.22)
        arp = [0.0] * int(sr * 0.6)
        for i, st in enumerate((0, 4, 7, 12)):
            w = self.pluck(660 * 2 ** (st / 12), 0.3)
            off = int(i * 0.08 * sr)
            for j, v in enumerate(w):
                if off + j < len(arp):
                    arp[off + j] += v
        self.sounds["level"] = self.make(arp, 0.25)
        beep = self.sweep(720, 700, 0.14, square=True, decay=0.5)
        gap = [0.0] * int(sr * 0.07)
        beep2 = self.sweep(560, 540, 0.3, square=True, decay=0.8)
        self.sounds["beep"] = self.make(beep + gap + beep + gap + beep2, 0.3)
        rev = []
        for f0, f1, d in ((70, 190, 0.35), (120, 230, 0.3), (140, 320, 0.55)):
            rev += self.sweep(f0, f1, d, noise=0.35, square=True, decay=0.6)
        pops = self.sweep(120, 40, 0.08, noise=0.8, decay=6)
        self.sounds["bmw"] = self.make(rev + pops + pops + pops, 0.45)
        self._build_music()

    def mix(self, s):
        return s

    def make(self, samples, vol=1.0):
        buf = array("h", (int(clamp(s * vol, -1.0, 1.0) * 32767) for s in samples))
        if self.ch == 2:
            st = array("h", [0]) * (len(buf) * 2)
            st[0::2] = buf
            st[1::2] = buf
            buf = st
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def sweep(self, f0, f1, dur, noise=0.0, decay=5.0, square=False):
        sr = self.sr
        n = int(sr * dur)
        out = []
        ph = 0.0
        att = 0.004 * sr
        for i in range(n):
            t = i / n
            f = f0 + (f1 - f0) * t
            ph += 2 * math.pi * f / sr
            env = min(1.0, i / att) * math.exp(-decay * t)
            v = math.sin(ph)
            if square:
                v = 0.6 * (1 if v > 0 else -1) + 0.4 * v
            out.append(env * ((1 - noise) * v + noise * random.uniform(-1, 1)))
        return out

    def pluck(self, f, dur):
        sr = self.sr
        n = int(sr * dur)
        w = 2 * math.pi * f / sr
        att = 0.004 * sr
        out = []
        for i in range(n):
            t = i / sr
            env = math.exp(-t * 5.0) * min(1.0, i / att)
            out.append(env * (0.6 * math.sin(w * i) + 0.3 * math.exp(-t * 3) * math.sin(2 * w * i)
                              + 0.15 * math.exp(-t * 7) * math.sin(3 * w * i)))
        return out

    def _build_music(self):
        """საქეიფო მუსიკა 6/8-ში: გარმონი (მელოდია), ფანდური (აკორდები), დოლი და ბანი."""
        try:
            sr = self.sr
            e8 = 0.15
            n_total = int(round(sr * e8 * 96))
            buf = [0.0] * n_total
            cache = {}

            def add(wave, start, vol):
                for j, v in enumerate(wave):
                    buf[(start + j) % n_total] += v * vol

            def garmoni(st, n8):
                key = ("g", st, n8)
                if key not in cache:
                    f = 220 * 2 ** (st / 12)
                    n = int(sr * e8 * n8 * 0.95)
                    out = []
                    ph = ph2 = 0.0
                    att, rel = 0.012 * sr, 0.03 * sr
                    for i in range(n):
                        t = i / sr
                        ff = f * (1 + 0.004 * math.sin(2 * math.pi * 5.5 * t))
                        ph += 2 * math.pi * ff / sr
                        ph2 += 2 * math.pi * ff * 1.005 / sr
                        env = min(1.0, i / att, (n - i) / rel)
                        out.append(env * (0.5 * math.sin(ph) + 0.3 * math.sin(ph2) + 0.3 * math.sin(2 * ph)
                                          + 0.2 * math.sin(3 * ph) + 0.12 * math.sin(4 * ph)))
                    cache[key] = out
                return cache[key]

            def pl(st):
                key = ("p", st)
                if key not in cache:
                    cache[key] = self.pluck(220 * 2 ** (st / 12), 0.35)
                return cache[key]

            boom = []
            for i in range(int(sr * 0.22)):
                t = i / sr
                boom.append(math.exp(-t * 18) * math.sin(2 * math.pi * (90 - 120 * t) * t * 1.0))
            tak = [math.exp(-i / (sr * 0.012)) * random.uniform(-1, 1) for i in range(int(sr * 0.06))]

            melody = [(12, 2), (15, 1), (14, 2), (12, 1), (10, 1), (12, 1), (14, 1), (15, 3),
                      (17, 2), (15, 1), (14, 2), (12, 1), (14, 3), (10, 3),
                      (12, 2), (15, 1), (14, 2), (12, 1), (10, 1), (12, 1), (14, 1), (15, 2), (14, 1),
                      (12, 1), (10, 1), (8, 1), (7, 2), (8, 1), (7, 3), (None, 3),
                      (19, 2), (17, 1), (15, 2), (17, 1), (19, 1), (20, 1), (19, 1), (17, 3),
                      (15, 2), (14, 1), (12, 2), (14, 1), (15, 3), (12, 3),
                      (19, 2), (17, 1), (15, 2), (14, 1), (12, 1), (14, 1), (15, 1), (14, 2), (12, 1),
                      (10, 1), (12, 1), (14, 1), (12, 2), (10, 1), (12, 3), (7, 1), (10, 1), (12, 1)]
            pos = 0
            for st, n8 in melody:
                if st is not None:
                    add(garmoni(st, n8), int(pos * e8 * sr), 0.30)
                pos += n8
            roots = [0, -2, -4, -5, 0, -2, -4, -5, 3, -2, 0, -5, 3, -2, -4, 0]
            for bar, rt in enumerate(roots):
                for k in range(6):
                    start = int((bar * 6 + k) * e8 * sr)
                    if k in (0, 3):
                        add(boom, start, 0.55)
                    if k in (2, 5):
                        add(tak, start, 0.18)
                    if k in (0, 2, 3, 5):
                        v = 0.16 if k in (0, 3) else 0.1
                        for d in (-12, -5, 0):
                            add(pl(rt + d), start + int(abs(d) * 0.0008 * sr), v)
            for i in range(n_total):
                buf[i] += 0.035 * math.sin(2 * math.pi * 110 * i / sr)
            peak = max(abs(v) for v in buf) or 1.0
            self.music = self.make([v / peak * 0.9 for v in buf], 0.6)
        except Exception:
            self.music = None

    def play(self, name):
        if self.ok and not self.muted and name in self.sounds:
            self.sounds[name].play()

    def update(self):
        if self.ok and self.music is not None and not self.music_started:
            self.music_channel = self.music.play(-1)
            self.music_started = True
            if self.music_channel:
                self.music_channel.set_volume(0 if self.muted else 0.5)

    def toggle_mute(self):
        self.muted = not self.muted
        if self.music_channel:
            self.music_channel.set_volume(0 if self.muted else 0.5)


# ----------------------------------------------------------------------------
# შენახვა
# ----------------------------------------------------------------------------
def save_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "GhipianiTamada")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return os.path.join(d, "save.json")


def load_save():
    try:
        with open(save_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
            return int(data.get("best", 0)), int(data.get("total_khinkali", 0))
    except Exception:
        return 0, 0


def write_save(best, total):
    try:
        with open(save_path(), "w", encoding="utf-8") as f:
            json.dump({"best": best, "total_khinkali": total}, f)
    except Exception:
        pass


# ----------------------------------------------------------------------------
# სირთულე
# ----------------------------------------------------------------------------
# s = სირთულე: ქულა + დრო (წამებში) * 0.6 — დროთა განმავლობაში ჩქარდება და რთულდება
def speed_for(s):
    return min(430.0, 165.0 + 2.4 * s)


def gap_for(s):
    return max(178.0, 285.0 - 1.3 * s)


def spacing_for(s):
    return max(205.0, 300.0 - 1.3 * s)


# ----------------------------------------------------------------------------
# ობიექტები
# ----------------------------------------------------------------------------
class Coin:
    def __init__(self, x, y, building=None, dy=0.0):
        self.x = x
        self.y = y
        self.building = building
        self.dy = dy
        self.phase = random.uniform(0, math.tau)
        self.taken = False

    def pos(self, t):
        y = self.building.gap_c + self.dy if self.building else self.y
        return self.x, y + math.sin(t * 3 + self.phase) * 5


class Van:
    def __init__(self):
        self.x = W + 60
        self.num = random.choice(["150", "162", "301", "88", "111", "44"])
        self.col = random.choice([(250, 200, 40), (245, 245, 240), (250, 200, 40)])

    def update(self, dt, speed):
        self.x -= (speed + 110) * dt

    def draw(self, S, night):
        x, y = int(self.x), GROUND_Y + 38
        pygame.draw.rect(S, (30, 30, 30), (x - 2, y - 2, 78, 34), border_radius=8)
        pygame.draw.rect(S, self.col, (x, y, 74, 30), border_radius=7)
        pygame.draw.polygon(S, self.col, [(x, y + 12), (x - 8, y + 18), (x - 8, y + 30), (x, y + 30)])
        for i in range(5):
            pygame.draw.rect(S, (70, 100, 130), (x + 4 + i * 13, y + 4, 10, 10), border_radius=2)
        t = text_surf("№" + self.num, 12, (200, 30, 30), None, 0)
        S.blit(t, (x + 30, y + 16))
        pygame.draw.circle(S, (20, 20, 20), (x + 12, y + 30), 7)
        pygame.draw.circle(S, (20, 20, 20), (x + 60, y + 30), 7)
        pygame.draw.circle(S, (150, 150, 150), (x + 12, y + 30), 3)
        pygame.draw.circle(S, (150, 150, 150), (x + 60, y + 30), 3)
        if night:
            pygame.draw.circle(S, (255, 240, 180), (x - 6, y + 21), 3)


# ----------------------------------------------------------------------------
# თამაში
# ----------------------------------------------------------------------------
def make_courier():
    """კურიერი ცისფერი ჩანთით, მფრინავ სკუტერზე."""
    S = pygame.Surface((110, 90), pygame.SRCALPHA)
    blue = (0, 160, 225)
    # სკუტერი
    pygame.draw.rect(S, (40, 40, 45), (18, 58, 66, 12), border_radius=6)
    pygame.draw.line(S, (40, 40, 45), (80, 60), (92, 34), 4)
    pygame.draw.line(S, (40, 40, 45), (86, 34), (98, 34), 3)
    pygame.draw.circle(S, (20, 20, 20), (28, 72), 9)
    pygame.draw.circle(S, (20, 20, 20), (80, 72), 9)
    pygame.draw.circle(S, (160, 160, 160), (28, 72), 4)
    pygame.draw.circle(S, (160, 160, 160), (80, 72), 4)
    # ჩანთა
    pygame.draw.rect(S, (20, 90, 140), (2, 22, 36, 34), border_radius=4)
    pygame.draw.rect(S, blue, (4, 24, 32, 30), border_radius=4)
    t = text_surf("Wolt", 13, (255, 255, 255), None, 0)
    S.blit(t, t.get_rect(center=(20, 39)))
    # კაცი
    skin = (150, 100, 70)
    pygame.draw.line(S, (40, 40, 60), (52, 56), (70, 60), 9)
    pygame.draw.rect(S, blue, (40, 30, 24, 28), border_radius=6)
    pygame.draw.line(S, blue, (60, 36), (88, 36), 7)
    pygame.draw.circle(S, skin, (89, 36), 4)
    pygame.draw.circle(S, skin, (54, 20), 10)
    pygame.draw.ellipse(S, (25, 20, 20), (47, 21, 16, 10))     # წვერი
    pygame.draw.ellipse(S, blue, (43, 6, 22, 12))               # ქუდი
    pygame.draw.rect(S, blue, (60, 12, 8, 4))
    pygame.draw.circle(S, (20, 20, 20), (59, 18), 2)
    return S


def make_bmw():
    """შავი BMW ხულიგანი — გამონაბოლქვით და მუსიკით."""
    S = pygame.Surface((150, 64), pygame.SRCALPHA)
    body = (22, 22, 26)
    pygame.draw.polygon(S, body, [(6, 40), (14, 28), (44, 26), (62, 10), (104, 10), (124, 26), (146, 30), (148, 46), (6, 48)])
    pygame.draw.polygon(S, (60, 80, 100), [(66, 14), (84, 14), (84, 26), (52, 26)])
    pygame.draw.polygon(S, (60, 80, 100), [(88, 14), (102, 14), (116, 26), (88, 26)])
    pygame.draw.line(S, (120, 120, 130), (6, 38), (148, 38), 1)
    pygame.draw.rect(S, (255, 240, 180), (138, 31, 9, 5))      # ფარი
    pygame.draw.rect(S, (60, 60, 70), (130, 31, 6, 9))
    pygame.draw.line(S, (200, 200, 210), (133, 32), (133, 39), 1)
    pygame.draw.rect(S, (230, 30, 30), (4, 32, 5, 6))
    for wx in (36, 116):
        pygame.draw.circle(S, (15, 15, 15), (wx, 48), 12)
        pygame.draw.circle(S, (170, 170, 180), (wx, 48), 6)
    t = text_surf("BMW", 11, (220, 220, 230), None, 0)
    S.blit(t, (70, 36))
    pygame.draw.circle(S, (230, 190, 150), (92, 20), 4)           # ხელი ფანჯრიდან
    return S


class Flyby:
    def __init__(self, kind, img):
        self.kind = kind
        self.img = img
        self.x = -img.get_width() - 10 if kind == "bmw" else W + 20
        self.vx = 560 if kind == "bmw" else -260
        self.y = GROUND_Y + GROUND_H - 8 - img.get_height()
        self.t = 0.0

    def update(self, dt):
        self.t += dt
        self.x += self.vx * dt

    def done(self):
        return self.x > W + 200 or self.x < -200

    def draw(self, S, particles):
        if self.kind == "bmw":
            y = self.y + abs(math.sin(self.t * 14)) * -3
            S.blit(self.img, (int(self.x), int(y)))
            if random.random() < 0.7:
                particles.append([self.x + 4, y + 42, random.uniform(-160, -60), random.uniform(-60, 0), 0.6, 0.6,
                                  random.choice([(120, 120, 125), (90, 90, 95), (255, 140, 40)]), random.randint(3, 6)])
            if int(self.t * 4) % 2 == 0:
                nx, ny = int(self.x + 80), int(y - 6 - (self.t * 30) % 20)
                pygame.draw.circle(S, (255, 230, 90), (nx, ny), 4)
                pygame.draw.line(S, (255, 230, 90), (nx + 3, ny), (nx + 3, ny - 14), 2)
                pygame.draw.line(S, (255, 230, 90), (nx + 3, ny - 14), (nx + 9, ny - 10), 2)
        else:
            y = self.y + abs(math.sin(self.t * 10)) * -2
            S.blit(self.img, (int(self.x), int(y)))


class Game:
    def __init__(self):
        try:
            self.screen = pygame.display.set_mode((W, H), pygame.SCALED | pygame.DOUBLEBUF)
        except Exception:
            self.screen = pygame.display.set_mode((W, H), pygame.SCALED)
        pygame.display.set_caption(TITLE)
        self.canvas = pygame.Surface((W, H)).convert()
        self.bg_tmp = pygame.Surface((W, H)).convert()
        self.dim_surf = pygame.Surface((W, H)).convert()
        self.dim_surf.fill((15, 20, 62))
        self.flash_surf = pygame.Surface((W, H)).convert()
        self.flash_surf.fill((255, 255, 255))
        self.clock = pygame.time.Clock()

        # ჩატვირთვის ეკრანი
        self.screen.fill((40, 30, 50))
        draw_text(self.screen, "იტვირთება...", 30, (W // 2, H // 2))
        pygame.display.flip()

        self.frames = {}
        for arm in (False, True):
            for leg in (-3, 0, 3):
                self.frames[(arm, leg)] = make_player_frame(arm, leg).convert_alpha()
        pygame.display.set_icon(pygame.transform.smoothscale(self.frames[(True, 0)], (64, 64)))
        self.khinkali_img = make_khinkali(46).convert_alpha()
        self.khinkali_small = make_khinkali(28).convert_alpha()

        rng = random.Random(1921)
        self.districts = []
        for d in DISTRICTS:
            self.districts.append(dict(d, sky_s=make_sky(d, rng), clouds_s=make_clouds(d, rng),
                                       far_s=make_far(d, rng), mid_s=make_mid(d, rng)))
        self.ground = make_ground(rng)
        for i in range(36):
            BUILDING_POOL.append(Building.render(random.Random(i * 7919 + 3)))
        self.courier_img = make_courier().convert_alpha()
        self.bmw_img = make_bmw().convert_alpha()
        self.audio = Audio()
        self.best, self.total_khinkali = load_save()
        self.state = "menu"
        self.time = 0.0
        self.reset()

    # ------------------------------------------------------------------
    def reset(self):
        self.py = H * 0.42
        self.vy = 0.0
        self.rot = 0.0
        self.flap_t = 0.0
        self.buildings = []
        self.coins = []
        self.particles = []
        self.floaters = []
        self.score = 0
        self.khinkali = 0
        self.speed = speed_for(0)
        self.spawn_dist = 0.0
        self.first_spawn = True
        self.scroll = 0.0
        self.district = 0
        self.prev_district = None
        self.fade = 1.0
        self.banner_t = 3.0
        self.dead_t = 0.0
        self.shake = 0.0
        self.flash = 0.0
        self.rng = random.Random()
        self.last_gap_c = H * 0.45
        self.play_time = 0.0
        self.flyby = None
        self.flyby_timer = self.rng.uniform(6, 12)
        self.van = None
        self.van_timer = self.rng.uniform(3, 8)
        self.death_msg = ""
        self.new_record = False
        self.paused = False

    # ------------------------------------------------------------------
    def flap(self):
        self.vy = FLAP_V
        self.flap_t = 0.18
        self.audio.play("flap")
        mx, my = PLAYER_X + 33, self.py - 42
        for _ in range(4):
            self.particles.append([mx, my, random.uniform(-40, 80), random.uniform(-160, -40), 0.6, 0.6,
                                   (150, 15, 40), random.randint(2, 3)])

    def start_game(self):
        self.reset()
        self.state = "play"
        self.banner_t = 2.5
        self.flap()

    def spawn(self):
        rng = self.rng
        s = self.diff()
        gap = gap_for(s)
        moving = s >= 10 and rng.random() < min(0.65, (s - 10) * 0.03 + 0.1)
        amp = min(70.0, 22.0 + (s - 10) * 1.0) if moving else 0.0
        lo = 100 + gap / 2 + amp
        hi = GROUND_Y - 80 - gap / 2 - amp
        maxd = 160 + min(140, s * 3)
        c = clamp(self.last_gap_c + rng.uniform(-maxd, maxd), lo, hi)
        x = W + (40 if self.first_spawn else 160)
        b = Building(x, c, gap, random.Random(rng.random()), moving, amp, rng.uniform(1.0, 1.8))
        cx = x + DECOR_M + BODY_W / 2
        if not self.first_spawn and rng.random() < 0.55:
            sp = spacing_for(s)
            self.coins.append(Coin(cx - sp / 2, (self.last_gap_c + c) / 2 + rng.uniform(-30, 30)))
        elif rng.random() < 0.55:
            self.coins.append(Coin(cx, 0, b, rng.uniform(-gap * 0.18, gap * 0.18)))
        self.buildings.append(b)
        self.last_gap_c = c
        self.first_spawn = False

    def die(self, ground=False):
        if self.state != "play":
            return
        self.state = "dead"
        self.dead_t = 0.0
        self.shake = 0.4
        self.flash = 0.25
        self.vy = -320 if not ground else 0
        self.death_msg = random.choice(GROUND_MSGS if ground else DEATH_MSGS)
        self.audio.play("hit")
        self.audio.play("die")
        for _ in range(18):
            self.particles.append([PLAYER_X, self.py, random.uniform(-200, 200), random.uniform(-250, 50), 0.8, 0.8,
                                   random.choice([(150, 15, 40), (240, 230, 200), (120, 120, 120)]),
                                   random.randint(2, 4)])
        self.total_khinkali += self.khinkali
        if self.score > self.best:
            self.best = self.score
            self.new_record = True
        write_save(self.best, self.total_khinkali)

    def diff(self):
        return self.score + self.play_time * 0.6

    def set_district(self, idx):
        if idx == self.district:
            return
        self.prev_district = self.district
        self.district = idx
        self.fade = 0.0
        self.audio.play("level")

    # ------------------------------------------------------------------
    def update(self, dt):
        self.time += dt
        self.audio.update()
        if self.paused:
            return
        if self.fade < 1.0:
            self.fade = min(1.0, self.fade + dt / 6.0)
        self.banner_t = max(0.0, self.banner_t - dt)
        self.shake = max(0.0, self.shake - dt)
        self.flash = max(0.0, self.flash - dt)
        self.flap_t = max(0.0, self.flap_t - dt)

        if self.state == "menu":
            self.scroll += 70 * dt
            self.py = H * 0.42 + math.sin(self.time * 2.5) * 14
            self.rot = math.sin(self.time * 2.5 + 1) * 6
            if int(self.time * 10) % 9 == 0 and self.flap_t <= 0:
                self.flap_t = 0.18
            self.update_particles(dt)
            return

        if self.state == "play":
            self.play_time += dt
            self.speed = speed_for(self.diff())
            self.scroll += self.speed * dt
            self.vy = min(MAX_FALL, self.vy + GRAVITY * dt)
            self.py += self.vy * dt
            if self.py < 30:
                self.py = 30
                self.vy = max(self.vy, 0)
            target = clamp(self.vy * 0.09, -28, 85)
            self.rot += (target - self.rot) * min(1.0, dt * 10)

            self.spawn_dist -= self.speed * dt
            if self.spawn_dist <= 0:
                self.spawn()
                self.spawn_dist += spacing_for(self.diff())
            for b in self.buildings:
                b.update(dt, self.speed)
            self.buildings = [b for b in self.buildings if b.x + b.width > -20]
            for c in self.coins:
                c.x -= self.speed * dt
            self.coins = [c for c in self.coins if c.x > -40 and not c.taken]

            # ქულა
            for b in self.buildings:
                if not b.passed and b.x + DECOR_M + BODY_W / 2 < PLAYER_X:
                    b.passed = True
                    self.score += 1
                    self.audio.play("point")
                    self.set_district((self.score // 10) % len(self.districts))

            # ხინკალი
            for c in self.coins:
                cx, cy = c.pos(self.time)
                if (cx - PLAYER_X) ** 2 + (cy - self.py) ** 2 < 40 ** 2:
                    c.taken = True
                    self.khinkali += 1
                    self.audio.play("coin")
                    self.floaters.append([cx, cy - 20, "+1", 0.9, 26, (255, 240, 200)])
                    for _ in range(10):
                        self.particles.append([cx, cy, random.uniform(-120, 120), random.uniform(-160, 40), 0.5, 0.5,
                                               random.choice([(255, 250, 230), (255, 220, 120)]), 2])
                    if self.khinkali % 10 == 0:
                        self.floaters.append([W / 2, 300, "ალავერდი! " + str(self.khinkali) + " ხინკალი!", 1.8, 30,
                                              (255, 210, 110)])
                        self.audio.play("level")

            # შეჯახება
            belly = (PLAYER_X - 1, self.py + 7, 21)
            head = (PLAYER_X + 1, self.py - 29, 12)
            for b in self.buildings:
                if b.x > PLAYER_X + 60 or b.x + b.width < PLAYER_X - 60:
                    continue
                for r in b.rects():
                    if circle_rect(*belly, r) or circle_rect(*head, r):
                        self.die()
                        break
                if self.state != "play":
                    break
            if self.state == "play" and self.py + 34 >= GROUND_Y:
                self.py = GROUND_Y - 34
                self.die(ground=True)

            # ჩამფრენები: კურიერი და BMW
            self.flyby_timer -= dt
            if self.flyby is None and self.flyby_timer <= 0:
                kind = random.choice(["courier", "bmw"])
                self.flyby = Flyby(kind, self.courier_img if kind == "courier" else self.bmw_img)
                self.audio.play("beep" if kind == "courier" else "bmw")
            if self.flyby:
                self.flyby.update(dt)
                if self.flyby.done():
                    self.flyby = None
                    self.flyby_timer = self.rng.uniform(9, 18)

            # მარშრუტკა
            self.van_timer -= dt
            if self.van is None and self.van_timer <= 0:
                self.van = Van()
            if self.van:
                self.van.update(dt, self.speed)
                if self.van.x < -120:
                    self.van = None
                    self.van_timer = self.rng.uniform(8, 18)

        elif self.state == "dead":
            self.dead_t += dt
            if self.py + 34 < GROUND_Y:
                self.vy = min(MAX_FALL, self.vy + GRAVITY * dt)
                self.py = min(GROUND_Y - 34, self.py + self.vy * dt)
                self.rot += (90 - self.rot) * min(1.0, dt * 6)

        self.update_particles(dt)

    def update_particles(self, dt):
        for p in self.particles:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[3] += 700 * dt
            p[4] -= dt
        self.particles = [p for p in self.particles if p[4] > 0]
        for f in self.floaters:
            f[1] -= 40 * dt
            f[3] -= dt
        self.floaters = [f for f in self.floaters if f[3] > 0]

    # ------------------------------------------------------------------
    def composite(self, d, surf):
        surf.blit(d["sky_s"], (0, 0))
        for layer, sp, y in ((d["clouds_s"], 0.06, 30), (d["far_s"], 0.18, GROUND_Y - LAYER_H),
                             (d["mid_s"], 0.42, GROUND_Y - LAYER_H)):
            off = -(self.scroll * sp) % LW
            surf.blit(layer, (off - LW, y))
            surf.blit(layer, (off, y))

    def draw(self):
        c = self.canvas
        cur = self.districts[self.district]
        if self.fade < 1.0 and self.prev_district is not None:
            prev = self.districts[self.prev_district]
            self.composite(prev, c)
            self.composite(cur, self.bg_tmp)
            self.bg_tmp.set_alpha(int(self.fade * 255))
            c.blit(self.bg_tmp, (0, 0))
            dim = lerp(prev["dim"], cur["dim"], self.fade)
            night = cur.get("night", False) if self.fade > 0.5 else prev.get("night", False)
        else:
            self.composite(cur, c)
            dim = cur["dim"]
            night = cur.get("night", False)

        for b in self.buildings:
            b.draw(c)

        off = -self.scroll % LW
        c.blit(self.ground, (off - LW, GROUND_Y))
        c.blit(self.ground, (off, GROUND_Y))
        if self.van:
            self.van.draw(c, night)
        if self.flyby:
            self.flyby.draw(c, self.particles)

        if dim > 0:
            self.dim_surf.set_alpha(int(dim))
            c.blit(self.dim_surf, (0, 0))

        for co in self.coins:
            x, y = co.pos(self.time)
            c.blit(self.khinkali_img, self.khinkali_img.get_rect(center=(int(x), int(y))))

        leg = (-3, 0, 3)[int(self.time * 8) % 3]
        frame = self.frames[(self.flap_t > 0, leg)]
        img = pygame.transform.rotozoom(frame, -self.rot, 1.0)
        c.blit(img, img.get_rect(center=(PLAYER_X, int(self.py))))

        for p in self.particles:
            pygame.draw.circle(c, p[6], (int(p[0]), int(p[1])), p[7])
        for f in self.floaters:
            a = clamp(f[3] / 0.4, 0, 1) * 255
            draw_text(c, f[2], f[4], (f[0], f[1]), f[5], alpha=a)

        if self.state == "menu":
            self.draw_menu(c)
        elif self.state == "play":
            self.draw_hud(c)
        elif self.state == "dead":
            self.draw_hud(c, score=False)
            if self.dead_t > 0.5:
                self.draw_gameover(c)
        if self.paused:
            ov = pygame.Surface((W, H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 130))
            c.blit(ov, (0, 0))
            draw_text(c, "პაუზა", 56, (W // 2, H // 2 - 30))
            draw_text(c, "P — გაგრძელება", 24, (W // 2, H // 2 + 30))

        if self.flash > 0:
            self.flash_surf.set_alpha(int(self.flash / 0.25 * 200))
            c.blit(self.flash_surf, (0, 0))

        ox = oy = 0
        if self.shake > 0:
            m = int(self.shake * 30)
            ox, oy = random.randint(-m, m), random.randint(-m, m)
        self.screen.fill((0, 0, 0))
        self.screen.blit(c, (ox, oy))
        pygame.display.flip()

    def draw_banner(self, c):
        if self.banner_t <= 0:
            return
        t = self.banner_t
        a = clamp(min(t, 3.0 - t) / 0.4, 0, 1) * 255 if t < 3.0 else 255
        name = self.districts[self.district]["name"]
        draw_text(c, "უბანი " + str(self.district + 1), 20, (W // 2, 150), (255, 240, 210), alpha=a)
        draw_text(c, name, 36, (W // 2, 184), (255, 255, 255), alpha=a)

    def draw_hud(self, c, score=True):
        if score:
            draw_text(c, str(self.score), 64, (W // 2, 72), ow=4)
        c.blit(self.khinkali_small, (14, 14))
        draw_text(c, "× " + str(self.khinkali), 26, (48, 28), anchor="midleft")

    def draw_menu(self, c):
        draw_text(c, "ღიპიანი", 58, (W // 2, 120), (255, 214, 120), ow=4)
        draw_text(c, "თამადა", 66, (W // 2, 186), (255, 255, 255), ow=4)
        draw_text(c, "ფრენა თბილისის ცაში", 24, (W // 2, 246), (255, 240, 220))
        if int(self.time * 2) % 2 == 0:
            draw_text(c, "SPACE / კლიკი — დაწყება", 26, (W // 2, 520), (255, 255, 255))
        draw_text(c, "P — პაუზა   M — ხმა   F11 — ეკრანი", 18, (W // 2, 566), (240, 240, 240), ow=2)
        draw_text(c, "რეკორდი: " + str(self.best), 24, (W // 2, 620), (255, 220, 140))
        c.blit(self.khinkali_small, (W // 2 - 140, 650))
        draw_text(c, "სულ შეჭმული: " + str(self.total_khinkali), 22, (W // 2 - 104, 664), (255, 240, 220),
                  anchor="midleft")

    def draw_gameover(self, c):
        t = clamp((self.dead_t - 0.5) / 0.3, 0, 1)
        panel = pygame.Rect(0, 0, 400, 380)
        panel.center = (W // 2, int(lerp(H + 200, H // 2 - 20, 1 - (1 - t) ** 3)))
        pygame.draw.rect(c, (60, 35, 20), panel.inflate(8, 8), border_radius=22)
        pygame.draw.rect(c, (250, 236, 205), panel, border_radius=18)
        pygame.draw.rect(c, (170, 40, 50), (panel.x, panel.y + 18, panel.w, 6))
        dark = (70, 40, 25)
        draw_text(c, "თამადა დაეცა!", 38, (panel.centerx, panel.y + 60), (190, 30, 40), None, 0)
        msg = self.death_msg
        s = text_surf(msg, 20, dark, None, 0)
        if s.get_width() > panel.w - 30:
            s = pygame.transform.smoothscale(s, (panel.w - 30, s.get_height()))
        c.blit(s, s.get_rect(center=(panel.centerx, panel.y + 104)))
        draw_text(c, "შენობები: " + str(self.score), 30, (panel.centerx, panel.y + 160), dark, None, 0)
        c.blit(self.khinkali_img, (panel.centerx - 110, panel.y + 186))
        draw_text(c, "ხინკალი: " + str(self.khinkali), 28, (panel.centerx - 62, panel.y + 206), dark, None, 0,
                  anchor="midleft")
        draw_text(c, "რეკორდი: " + str(self.best), 26, (panel.centerx, panel.y + 256), (150, 100, 30), None, 0)
        if self.new_record and int(self.time * 3) % 2 == 0:
            draw_text(c, "ახალი რეკორდი!", 26, (panel.centerx, panel.y + 294), (220, 40, 50), None, 0)
        if self.dead_t > 1.0:
            draw_text(c, "SPACE — თავიდან   ESC — მენიუ", 20, (panel.centerx, panel.bottom - 30), dark, None, 0)

    # ------------------------------------------------------------------
    def action(self):
        if self.paused:
            return
        if self.state == "menu":
            self.start_game()
        elif self.state == "play":
            self.flap()
        elif self.state == "dead" and self.dead_t > 1.0:
            self.start_game()

    async def run(self):
        while True:
            dt = min(self.clock.tick(FPS) / 1000.0, 1 / 30)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return
                if e.type == pygame.KEYDOWN:
                    if e.key in (pygame.K_SPACE, pygame.K_UP, pygame.K_w, pygame.K_RETURN):
                        self.action()
                    elif e.key == pygame.K_ESCAPE:
                        if self.state == "menu":
                            return
                        if self.state == "play" and not self.paused:
                            self.paused = True
                        else:
                            self.paused = False
                            self.reset()
                            self.state = "menu"
                    elif e.key == pygame.K_p and self.state == "play":
                        self.paused = not self.paused
                    elif e.key == pygame.K_m:
                        self.audio.toggle_mute()
                    elif e.key == pygame.K_F11:
                        try:
                            pygame.display.toggle_fullscreen()
                        except Exception:
                            pass
                elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                    self.action()
                elif e.type == pygame.WINDOWFOCUSLOST and self.state == "play":
                    self.paused = True
            self.update(dt)
            self.draw()
            await asyncio.sleep(0)


async def main():
    global FONT_PATH
    pygame.mixer.pre_init(22050, -16, 1, 512)
    pygame.init()
    FONT_PATH = find_font()
    await Game().run()
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
